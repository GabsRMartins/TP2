#ifndef ESTADO
#define ESTADO



enum class Estado{ 
    CHEGOU, 
    FILA_TRIAGEM, SENDO_TRIADO, 
    FILA_ATENDIMENTO, SENDO_ATENDIDO, 
    FILA_MH , R_MH, 
    FILA_TL, R_TL,
    FILA_EI, R_EI,
    FILA_IM, R_IM,
    Alta
    };





  

#endif